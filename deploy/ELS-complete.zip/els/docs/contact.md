Contacting the ELS project is easy. We invite comments, suggestions, and complaints.

To interact you need a GitHub account and be logged-in.

For the appropriate bug problem and related technical stuff please use the Issues.

For general discussion, ideas, questions, etc. please use the Discussions.
